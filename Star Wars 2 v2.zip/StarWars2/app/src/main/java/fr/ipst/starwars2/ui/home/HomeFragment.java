package fr.ipst.starwars2.ui.home;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.androidnetworking.AndroidNetworking;
import com.androidnetworking.common.Priority;
import com.androidnetworking.error.ANError;
import com.androidnetworking.interfaces.JSONObjectRequestListener;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONException;
import org.json.JSONObject;

import fr.ipst.starwars2.R;

public class HomeFragment extends Fragment implements OnMapReadyCallback, GoogleMap.OnInfoWindowClickListener {

    private static final String starWarsApiBaseUrl = "https://swapi.dev/api/";
    private static final String LogTag = "StarWars";

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        HomeViewModel homeViewModel = ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        final TextView textView = root.findViewById(R.id.text_home);
        homeViewModel.getText().observe(getViewLifecycleOwner(), new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                textView.setText(s);
            }
        });
        addMapFragment();

        return root;
    }

    // This method adds map fragment to the container.
    private void addMapFragment() {
        SupportMapFragment mMapFragment = SupportMapFragment.newInstance();
        mMapFragment.getMapAsync(this);
        getChildFragmentManager().beginTransaction()
                .replace(R.id.map_container, mMapFragment)
                .commit();
    }

    @Override
    public void onMapReady(final GoogleMap googleMap) {
        // Add a marker in Sydney and move the camera
        final LatLng toulouse = new LatLng(43.6, 1.44);
        googleMap.moveCamera(CameraUpdateFactory.newLatLng(toulouse));

        // Skin the Markers tooltip
        googleMap.setInfoWindowAdapter(new CustomInfoWindowAdapter());

        for (int i = 1; i < 11; i++) {
            AndroidNetworking.get(starWarsApiBaseUrl + "people/{charNumber}/")
                    .addPathParameter("charNumber", Integer.toString(i))
                    // .addQueryParameter("limit", "3")
                    // .addHeaders("token", "1234")
                    .setTag("test")
                    .setPriority(Priority.LOW)
                    .build()
                    .getAsJSONObject(new JSONObjectRequestListener() {
                        @Override
                        public void onResponse(JSONObject response) {
                            // do anything with response
                            try {
                                Log.i(LogTag, response.getString("name"));
                                googleMap.addMarker(new MarkerOptions().position(getRandomLocation())
                                        .title(response.getString("name"))
                                        .snippet("height: " + response.getString("height") + "\n" +
                                                 "mass: " + response.getString("mass") + "\n" +
                                                 "hair color: " + response.getString("hair_color") + "\n" +
                                                 "skin color: " + response.getString("skin_color") + "\n" +
                                                 "eye color: " + response.getString("eye_color") + "\n" +
                                                 "birth year: " + response.getString("birth_year") + "\n" +
                                                 "gender: " + response.getString("gender")
                                        )).showInfoWindow();
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }

                        @Override
                        public void onError(ANError error) {
                            // handle error
                            Log.e(LogTag, error.toString());
                        }
                    });
        }

    }

    private LatLng getRandomLocation() {
        return new LatLng(1 + Math.random() * 50, 1 + Math.random() * 100);
    }

    private class CustomInfoWindowAdapter implements GoogleMap.InfoWindowAdapter {
        @Override
        public View getInfoWindow(Marker marker) {
            return null;
        }

        @Override
        public View getInfoContents(Marker marker) {
            View view = getActivity().getLayoutInflater().inflate(R.layout.custom_info_window, null);
            TextView tvTitle = (TextView) view.findViewById(R.id.tv_title);
            TextView tvSubTitle = (TextView) view.findViewById(R.id.tv_subtitle);

            tvTitle.setText(marker.getTitle());
            tvSubTitle.setText(marker.getSnippet());
            return view;
        }
    }

    @Override
    public void onInfoWindowClick(Marker marker) {

    }

}